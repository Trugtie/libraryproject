<!-- single -->
<div class="card col-xl-12 col-lg-6 col-md-6 col-sm-10 bg-transparent">
    <div class="row">
        <div class="col-md-3 card-img">
            <img class="img-fluid " src="https://via.placeholder.com/150x150" alt="">
        </div>
        <div class="col-md-9 p-1">
            <a href="javascript:void();" class="badge badge-success">Thể loại</a>
            <h4><a href="news_post.php">Tiêu đề</a></h4>
            <span>Đăng bởi Admin - Jun 19, 2020</span>
        </div>
    </div>
</div>
<!-- single -->