<!-- TIN NOI BAT -->
<div class="container">
    <!-- Section Tittle -->
    <h4>Tin nổi bật</h4>
    <!-- Details -->
    <div class="card bg-transparent">
        <img class="img-fluid " src="https://via.placeholder.com/350x400" alt="">
        <div class="card-img-overlay">
            <a href="javascript:void();" class="badge badge-success">Thể loại</a>
            <h4><a href="news_post.php">Title</a></h4>
            <p>Admin | 2 hours ago</p>
        </div>
    </div>
    <?php include "single-right-archive.php" ?>
    <?php include "single-right-archive.php" ?>    
</div>
<!-- TIN NOI BAT -->

<!-- CATEGORY -->
<aside>
    <h4>Danh mục</h4>
    <ul>
        <li>
            <a href="#" class="d-flex">
                <p>Tin tức tổng hợp</p>
                <p>(37)</p>
            </a>
        </li>
        <li>
            <a href="#" class="d-flex">
                <p>Tin tuyển dụng</p>
                <p>(10)</p>
            </a>
        </li>
        <li>
            <a href="#" class="d-flex">
                <p>Tin tức hướng nghiệp</p>
                <p>(11)</p>
            </a>
        </li>
        <li>
            <a href="#" class="d-flex">
                <p>Học - Thi -Tuyển Sinh</p>
                <p>(21)</p>
            </a>
        </li>
        <li>
            <a href="#" class="d-flex">
                <p>Sinh viên STU</p>
                <p>(21)</p>
            </a>
        </li>
    </ul>
</aside>
<!-- CATEGORY -->