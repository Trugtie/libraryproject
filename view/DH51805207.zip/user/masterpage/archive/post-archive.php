<!-- Breadcrumb -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <nav aria-label="">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="home.php"><i class="fa fa-home" aria-hidden="true"></i> Trang chủ</a></li>
                    <li class="breadcrumb-item"><a href="news.php">Tin tức</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Tiêu đề bài đăng</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Main Content -->
<?php include "post-archive-content.php" ?>