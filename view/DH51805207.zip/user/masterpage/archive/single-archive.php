<article class="row">
    <div class="card-img col-md-3 ">
        <img class="img-fluid " src="https://via.placeholder.com/200x200" alt="">
    </div>

    <div class="card-body col-md-9">
        <a class="d-inline-block" href="news_post.php">
            <h4>STU thông báo tuyển sinh đào tạo trình độ thạc sĩ năm 2021 ngành Công nghệ Thực phẩm.</h4>
        </a>
        <p>Trong hơn 24 năm xây dựng và phát triển của mình, STU đã khẳng định là một thương hiệu tốt, uy tín trong việc đào tạo nguồn nhân lực có chất lượng, vững lý thuyết,
            giỏi thực hành, kỹ năng tốt và đã đáp ứng được yêu cầu ngày càng cao của xã hội....</p>
        <ul>
            <li>
                <a href="javascript:void();" class="badge badge-success">Thể loại</a>
            </li>
            <li>
                <a href="#"><i class="fa fa-user"></i>&#9 Admin | 2 hours ago</a>
            </li>
        </ul>
    </div>
</article>
<hr />