<div class="card bg-transparent">
    <div class="card-img">
        <img class="img-fluid " src="https://via.placeholder.com/500x500" alt="">
    </div>
    <div class="card-img-overlay">
        <a href="javascript:void();" class="badge badge-success">Thể loại</a>
        <h4><a href="news_post.php">Title</a></h4>
        <p>Admin | 2 hours ago</p>
    </div>
</div>