<!-- Single -->
<div class="card bg-transparent">
        <div class="row d-flex justify-content-between">
            <div class="col-md-4 card-img">
                <img class="img-fluid " src="https://via.placeholder.com/300x300" alt="">
            </div>
            <div class="col-md-8">
                <a href="javascript:void();" class="badge badge-success">Thể loại</a>
                <h5><a href="news_post.php">Title</a></h5>
                <p>Admin | 2 hours ago</p>
            </div>
        </div>
    </div>
    <!-- Single -->