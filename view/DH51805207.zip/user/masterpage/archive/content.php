<h5>Trong hơn 24 năm xây dựng và phát triển của mình, STU đã khẳng định là một thương hiệu tốt, uy tín trong việc đào tạo nguồn nhân lực có chất lượng, vững lý thuyết, giỏi thực hành,
    kỹ năng tốt và đã đáp ứng được yêu cầu ngày càng cao của xã hội. Trên cơ sở đó, từ năm học 2016 - 2017, STU đã được Bộ Giáo dục & Đào tạo cho phép đào tạo trình độ Thạc sĩ chuyên ngành Công nghệ Thực phẩm.
    Khóa 1-2 của chương trình đã tốt nghiệp.</h5>

<p>Tiếp nối thành công, trường Đại học Công nghệ Sài Gòn (STU) thông báo tuyển sinh trình độ Thạc sĩ 2021 chuyên ngành Công nghệ Thực phẩm.

    Theo đó, Trường STU nhận hồ sơ từ ngày ra thông báo đến hết ngày 27/11/2021.</p>



<ul>
    <h5>Các mốc thời gian quan trọng:</h5>
    <li>
        Từ ngày ra thông báo - 30/10/2021: Đăng ký và học bổ sung kiến thức.
    </li>
    <li>
        Từ ngày ra thông báo - 30/10/2021: Đăng ký và ôn tập thi tuyển sinh.
    </li>
    <li>
        11-12/122021: THI TUYỂN SINH.
    </li>
    <li>
        Dự kiến nhập học 03/01/2022.
    </li>
    <h5>Thời gian Đào tạo: 1.5 năm. </h5>
    <h5>Đối tượng dự thi:</h5>
    <li>
        Tốt nghiệp ĐH ngành Công nghệ Thực phẩm.
    </li>
    <li>
        Tốt nghiệp ĐH các ngành Công nghệ Sau thu hoạch, Công nghệ Chế biến Thủy sản và đã học bổ sung kiến thức.
    </li>
</ul>