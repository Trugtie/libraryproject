<!--Start footer-->
<footer class="footer">
    <div class="container">
        <div class="text-center">
            Copyright © 2018
        </div>
    </div>
</footer>
<!--End footer-->
<!-- Bootstrap core JavaScript-->
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="../assets/plugins/simplebar/js/simplebar.js"></script>
<!-- sidebar-menu js -->
<script src="../assets/js/sidebar-menu.js"></script>

<!-- Custom scripts -->
<script src="../assets/js/app-script.js"></script>

<!-- Toast -->
<script>
    $(document).ready(function () {
        $("#applyBtn").click(function () {
            $('.toast').toast('show');
        });
    });
</script>